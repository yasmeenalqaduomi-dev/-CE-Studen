const quizData = [
    { question: "ما هو المكون الأساسي لمعالجة البيانات في الحاسوب؟", options: ["CPU", "RAM", "Hard Disk", "GPU"], answer: "CPU" },
    { question: "أي لغة برمجة تُستخدم لتطوير تطبيقات Android؟", options: ["Java", "Python", "C", "HTML"], answer: "Java" },
    { question: "ما وظيفة الRAM؟", options: ["تخزين دائم", "تخزين مؤقت", "تشغيل الإنترنت", "توليد الطاقة"], answer: "تخزين مؤقت" },
    { question: "ما هو البروتوكول المستخدم لإرسال صفحات الويب؟", options: ["HTTP", "FTP", "SMTP", "DNS"], answer: "HTTP" },
    { question: "ما هو نظام التشغيل مفتوح المصدر الشهير؟", options: ["Windows", "Linux", "MacOS", "DOS"], answer: "Linux" }
];
let currentQuestion = 0;
let score = 0;
const questionEl = document.getElementById("question");
const optionsEl = document.getElementById("options");
const nextBtn = document.getElementById("next-btn");
const resultSection = document.getElementById("result-section");
const quizSection = document.getElementById("quiz-section");
const scoreEl = document.getElementById("score");
const restartBtn = document.getElementById("restart-btn");

function loadQuestion() {
    const current = quizData[currentQuestion];
    questionEl.textContent = current.question;
    optionsEl.innerHTML = "";
    current.options.forEach(option => {
        const btn = document.createElement("button");
        btn.textContent = option;
        btn.classList.add("option-btn");
        btn.addEventListener("click", () => selectOption(option));
        optionsEl.appendChild(btn);
    });
}

function selectOption(selected) {
    const correct = quizData[currentQuestion].answer;
    if (selected === correct) { score++; alert("إجابة صحيحة!"); } 
    else { alert("خطأ! الإجابة الصحيحة: " + correct); }
    currentQuestion++;
    if (currentQuestion < quizData.length) { loadQuestion(); } 
    else { showResult(); }
}

function showResult() {
    quizSection.classList.add("hidden");
    resultSection.classList.remove("hidden");
    scoreEl.textContent = `لقد حصلت على ${score} من ${quizData.length}`;
}

nextBtn.addEventListener("click", () => loadQuestion());
restartBtn.addEventListener("click", () => {
    currentQuestion = 0; score = 0;
    resultSection.classList.add("hidden");
    quizSection.classList.remove("hidden");
    loadQuestion();
});

loadQuestion();